# ForgeClient189 — Minecraft 1.8.9 Forge Client

This is a Forge 1.8.9 client project using ForgeGradle 2.1.

## Important build requirement

ForgeGradle 2.1 is an old build toolchain. Build this project with **Java 8**, not Java 17/21.
The repository includes a Codespaces configuration that uses the Java 8 devcontainer image.

## GitHub Codespaces — easiest method

1. Create a GitHub repository and upload the **contents** of this project so `build.gradle` is in the repository root.
2. Open **Code → Codespaces → Create codespace on main**.
3. Wait for the Codespace container to finish creating. It is configured for Java 8.
4. Open the terminal in VS Code and run:

```bash
./gradlew --version
./gradlew setupDecompWorkspace
./gradlew build
```

The first run downloads the old ForgeGradle/Forge dependencies and may take several minutes.

If the build succeeds, the compiled mod JAR is under:

```text
build/libs/
```

## If Codespaces does not automatically rebuild the container

Use **Command Palette → Codespaces: Rebuild Container** and wait for it to finish. Then run the three commands above again.

## Client menu

Press **Right Shift** in Minecraft to open the client menu.

## Important scope note

The project contains a real module/settings/config framework and many working client features. Complex third-party systems such as ReplayMod, Minimap, Mumble Link, WorldEdit CUI, and full SkyBlock/Dungeon route systems are not represented as fake toggles; they require their own substantial implementations/integrations.


## Clean feature set

This build intentionally does not register placeholder/decorative modules. Features without a real runtime implementation were removed from the menu, including fake Hypixel/BedWars/Tier-tag/stat modules, placeholder bossbar/shiny-potion/saturation/particle modules, and unused settings. Every registered setting is consumed by the corresponding feature code.

Known runtime-dependent features (Hurt Cam, Item Physics, Motion Blur, FreeLook) use Forge/ASM/OpenGL hooks and must be tested on the target Forge 1.8.9 runtime.
