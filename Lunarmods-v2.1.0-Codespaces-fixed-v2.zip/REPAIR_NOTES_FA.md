# LunarMods v2.1.0 — Full feature repair pass

این نسخه یک pass کامل روی moduleهای موجود پروژه انجام می‌دهد.

## پیاده‌سازی‌های واقعی اضافه‌شده
- No Hurt Cam با Coremod/ASM روی EntityRenderer
- Motion Blur با frame feedback و آزادسازی textureها
- FreeLook با CameraSetup و کنترل Mouse
- Toggle Sneak با حالت toggle واقعی
- Waypoints با ثبت و رندر نقطه در جهان
- Hitbox برای Player/Mob/Item با رندر bounding box
- Block Outline با رندر bounding box بلوک هدف
- Hit Color با RenderLivingEvent
- Scoreboard renderer مستقل
- Cooldowns برای آیتم فعال
- FOV dynamic/static
- Quickplay با keybind قابل تنظیم
- UHC Overlay برای شمارش head/golden apple
- Chat ping sound
- Nametag renderer
- Item Physics با ASM hook روی RenderEntityItem

## مواردی که به داده خارجی نیاز دارند
Tier Tagger، آمار BedWars، بعضی قابلیت‌های Hypixel و سیستم‌های شبکه‌ای کامل بدون API/فرمت داده مشخص سرور قابل پیاده‌سازی قابل‌اعتماد نیستند. در این نسخه برای آن‌ها داده جعلی تولید نشده است.

## Build
پروژه برای Forge 1.8.9 و Java 8 است. این محیط به Maven/Gradle اینترنتی دسترسی نداشت، بنابراین JAR نهایی اینجا compile/runtime-test نشده است. قبل از استفاده، روی Java 8 اجرا کنید:

```bash
./gradlew clean build
```
