#!/usr/bin/env bash
set -e

grep -q 'shouldCancelHurtCam' src/main/java/com/example/client/ForgeClient.java
grep -q 'HurtCamTransformer' src/main/java/com/example/client/core/LunarLoadingPlugin.java
grep -q 'glCopyTexSubImage2D' src/main/java/com/example/client/feature/Features.java
grep -q "FMLCorePlugin" build.gradle
echo 'Source-level repair checks passed.'
