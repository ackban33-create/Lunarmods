#!/usr/bin/env bash
set -e
[ -f build.gradle ]
[ -f settings.gradle ]
[ -x gradlew ]
[ -f .devcontainer/devcontainer.json ]
[ -f src/main/resources/mcmod.info ]
find src/main/java -name '*.java' -print >/dev/null
printf 'Project structure OK.\n'
printf 'Java requirement: 8\n'
printf 'Gradle bootstrap: 2.14.1\n'
