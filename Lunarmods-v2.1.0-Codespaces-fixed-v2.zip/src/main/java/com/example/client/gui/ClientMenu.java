package com.example.client.gui;

import com.example.client.config.ConfigManager;
import com.example.client.module.*;
import com.example.client.setting.*;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ChatAllowedCharacters;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.io.IOException;
import java.util.*;

public class ClientMenu extends GuiScreen {
 private final ModuleManager manager; private final ConfigManager config; private String category="HUD",search=""; private Module selected; private int scroll=0; private boolean searchFocus=false; private Setting<?> dragging;
 private final int bg=0xF20B0D12,panel=0xF2181B24,card=0xF51E222C,card2=0xF5252A35,accent=0xFF4D8DFF,text=0xFFF4F6FA,muted=0xFF8F98AA,green=0xFF5DE0A1,red=0xFFFF667D;
 public ClientMenu(ModuleManager m,ConfigManager c){manager=m;config=c;}
 public void initGui(){Keyboard.enableRepeatEvents(true);}
 public void onGuiClosed(){Keyboard.enableRepeatEvents(false);config.save(manager);}
 public void drawScreen(int mx,int my,float pt){ScaledResolution sr=new ScaledResolution(mc);int w=sr.getScaledWidth(),h=sr.getScaledHeight();drawRect(0,0,w,h,bg);int x=22,y=18;
  drawRect(x,y,190,h-18,panel);drawString("FORGE",x+20,y+20,accent);drawString("CLIENT",x+68,y+20,text);drawString("1.8.9",x+20,y+38,muted);
  drawRect(x+15,y+55,177,y+82,0xFF11141B);drawString(search.length()==0?"Search modules...":search,x+25,y+64,search.length()==0?muted:text);
  int cy=y+100;for(String cat:manager.categories()){boolean on=cat.equals(category);if(on)drawRect(x+10,cy-5,182,cy+25,0xFF252A35);drawString(cat,x+24,cy+5,on?text:muted);cy+=29;}
  int mainX=205;drawString(category,mainX,y+12,text);drawString("Right Shift",w-88,y+12,muted);
  int listY=y+43;List<Module> list=new ArrayList<Module>();for(Module m:manager.getModules())if(m.getCategory().equals(category)&&(search.isEmpty()||m.getName().toLowerCase().contains(search.toLowerCase())))list.add(m);
  int cardW=230,cardH=54;int cols=Math.max(1,(w-mainX-25)/(cardW+10));for(int i=0;i<list.size();i++){int col=i%cols,row=i/cols;int cx=mainX+col*(cardW+10),cy2=listY+row*(cardH+8)+scroll;if(cy2+cardH<listY||cy2>h-18)continue;Module m=list.get(i);drawRect(cx,cy2,cx+cardW,cy2+cardH,m==selected?card2:card);drawString(m.getName(),cx+12,cy2+10,text);drawString(m.getDescription().length()==0?m.getCategory():m.getDescription(),cx+12,cy2+27,muted);drawRect(cx+cardW-43,cy2+16,cx+cardW-15,cy2+30,m.isEnabled()?0xFF245E49:0xFF3A3E49);drawString(m.isEnabled()?"ON":"OFF",cx+cardW-40,cy2+19,m.isEnabled()?green:muted);}
  if(selected!=null)drawSettings(selected,w,h,mx,my);super.drawScreen(mx,my,pt);
 }
 private void drawSettings(Module m,int w,int h,int mx,int my){int pw=Math.min(390,w-230),px=w-pw-15,py=42;drawRect(px,py,w-15,h-18,0xFC10131A);drawString(m.getName(),px+18,py+18,text);drawString(m.getCategory(),px+18,py+35,muted);drawRect(px+15,py+55,w-30,py+91,card);drawString("Enabled",px+28,py+68,text);drawString(m.isEnabled()?"ON":"OFF",w-72,py+68,m.isEnabled()?green:red);int yy=py+104;for(Setting<?> s:m.getSettings()){if(yy>h-45)break;drawString(s.getName(),px+20,yy, text);String val=value(s);drawString(val,w-55-mc.fontRendererObj.getStringWidth(val),yy,muted);if(s instanceof NumberSetting){NumberSetting n=(NumberSetting)s;int bx=px+20,by=yy+14,bw=pw-40;drawRect(bx,by,bx+bw,by+3,0xFF303642);double f=(n.get()-n.min)/(n.max-n.min);drawRect(bx,by,bx+(int)(bw*f),by+3,accent);}yy+=48;}}
 private String value(Setting<?> s){if(s instanceof BooleanSetting)return ((BooleanSetting)s).get()?"ON":"OFF";if(s instanceof NumberSetting)return String.format("%.2f",((NumberSetting)s).get());if(s instanceof KeySetting){int k=((KeySetting)s).get();return k==Keyboard.KEY_NONE?"NONE":Keyboard.getKeyName(k);}return String.valueOf(s.get());}
 public void mouseClicked(int mx,int my,int button)throws IOException{ScaledResolution sr=new ScaledResolution(mc);int w=sr.getScaledWidth(),h=sr.getScaledHeight();int x=22,y=18;
  if(mx>=x+15&&mx<=177&&my>=y+55&&my<=y+82){searchFocus=true;return;}if(mx>=x&&mx<=190){int cy=y+100;for(String cat:manager.categories()){if(my>=cy-5&&my<=cy+25){category=cat;selected=null;scroll=0;return;}cy+=29;}}
  int mainX=205,listY=y+43,cardW=230,cardH=54;List<Module> list=new ArrayList<Module>();for(Module m:manager.getModules())if(m.getCategory().equals(category)&&(search.isEmpty()||m.getName().toLowerCase().contains(search.toLowerCase())))list.add(m);int cols=Math.max(1,(w-mainX-25)/(cardW+10));for(int i=0;i<list.size();i++){int col=i%cols,row=i/cols,cx=mainX+col*(cardW+10),cy=listY+row*(cardH+8)+scroll;if(mx>=cx&&mx<=cx+cardW&&my>=cy&&my<=cy+cardH){Module m=list.get(i);if(button==0){selected=m;}else if(button==1){m.toggle();config.save(manager);}return;}}
  if(selected!=null){int pw=Math.min(390,w-230),px=w-pw-15,py=42;if(mx>=px+15&&mx<=w-30&&my>=py+55&&my<=py+91){selected.toggle();config.save(manager);return;}int yy=py+104;for(Setting<?> s:selected.getSettings()){if(my>=yy-4&&my<=yy+32&&mx>=px+15&&mx<=w-30){if(s instanceof BooleanSetting){((BooleanSetting)s).toggle();}else if(s instanceof NumberSetting){dragging=s;setNumber((NumberSetting)s,mx,px+20,pw-40);}else if(s instanceof EnumSetting){((EnumSetting)s).next();}else if(s instanceof KeySetting){int v=((KeySetting)s).get();((KeySetting)s).set(v==Keyboard.KEY_NONE?Keyboard.KEY_0:Keyboard.KEY_NONE);}config.save(manager);return;}yy+=48;}}
 }
 private void setNumber(NumberSetting n,int mx,int bx,int bw){double f=Math.max(0,Math.min(1,(mx-bx)/(double)bw));double v=n.min+f*(n.max-n.min);v=Math.round(v/n.step)*n.step;n.set(v);}
 public void mouseClickMove(int mx,int my,int button,long time){if(dragging instanceof NumberSetting){ScaledResolution sr=new ScaledResolution(mc);int w=sr.getScaledWidth(),pw=Math.min(390,w-230),px=w-pw-15;setNumber((NumberSetting)dragging,mx,px+20,pw-40);}}
 public void mouseReleased(int mx,int my,int button){dragging=null;config.save(manager);}
 public void handleMouseInput()throws IOException{super.handleMouseInput();int d=Mouse.getDWheel();if(d!=0){scroll+=d>0?20:-20;scroll=Math.min(0,Math.max(-400,scroll));}}
 protected void keyTyped(char c,int key)throws IOException{if(searchFocus){if(key==Keyboard.KEY_ESCAPE){searchFocus=false;return;}if(key==Keyboard.KEY_BACK){if(search.length()>0)search=search.substring(0,search.length()-1);return;}if(ChatAllowedCharacters.isAllowedCharacter(c)&&search.length()<24)search+=c;return;}if(key==Keyboard.KEY_ESCAPE){mc.displayGuiScreen(null);return;}super.keyTyped(c,key);}
 public boolean doesGuiPauseGame(){return false;}
 private void drawString(String s,int x,int y,int c){mc.fontRendererObj.drawString(s,x,y,c);}
}
