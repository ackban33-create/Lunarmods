package com.example.client.core;

import net.minecraft.launchwrapper.IClassTransformer;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

public class HurtCamTransformer implements IClassTransformer {
    public byte[] transform(String name, String transformedName, byte[] basicClass) {
        if (basicClass == null) return basicClass;
        ClassNode cn = new ClassNode();
        new ClassReader(basicClass).accept(cn, 0);
        boolean changed=false;
        if ("net.minecraft.client.renderer.EntityRenderer".equals(transformedName) || "bfr".equals(name)) {
            for (Object item : cn.methods) {
                MethodNode mn = (MethodNode)item;
                if (("hurtCameraEffect".equals(mn.name) || "func_78482_e".equals(mn.name)) && "(F)V".equals(mn.desc)) {
                    InsnList hook = new InsnList(); LabelNode cont = new LabelNode();
                    hook.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "com/example/client/ForgeClient", "shouldCancelHurtCam", "()Z", false));
                    hook.add(new JumpInsnNode(Opcodes.IFEQ, cont)); hook.add(new InsnNode(Opcodes.RETURN)); hook.add(cont);
                    mn.instructions.insert(hook); changed=true; break;
                }
            }
        }
        if ("net.minecraft.client.renderer.entity.RenderEntityItem".equals(transformedName) || "zw".equals(name)) {
            for (Object item : cn.methods) {
                MethodNode mn=(MethodNode)item;
                if (mn.desc.contains("Lnet/minecraft/entity/item/EntityItem;")) {
                    for (int i=0;i<mn.instructions.size();i++) {
                        AbstractInsnNode n=mn.instructions.get(i);
                        if (n instanceof MethodInsnNode) {
                            MethodInsnNode mi=(MethodInsnNode)n;
                            if (mi.owner.equals("net/minecraft/client/renderer/GlStateManager") && mi.name.equals("translate") && mi.desc.equals("(DDD)V")) {
                                InsnList h=new InsnList();
                                h.add(new VarInsnNode(Opcodes.ALOAD,1)); h.add(new VarInsnNode(Opcodes.FLOAD,10));
                                h.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"com/example/client/ForgeClient","applyItemPhysics","(Lnet/minecraft/entity/item/EntityItem;F)V",false));
                                mn.instructions.insert(n,h); changed=true; break;
                            }
                        }
                    }
                }
                if(changed) break;
            }
        }
        return changed ? write(cn) : basicClass;
    }
    private byte[] write(ClassNode cn) {
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        return cw.toByteArray();
    }
}
