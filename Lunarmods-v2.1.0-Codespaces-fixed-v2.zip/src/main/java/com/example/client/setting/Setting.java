package com.example.client.setting;

public class Setting<T> {
    private final String id, name;
    private T value;
    public Setting(String id, String name, T value) { this.id=id; this.name=name; this.value=value; }
    public String getId(){return id;} public String getName(){return name;} public T get(){return value;} public void set(T v){value=v;}
}
