package com.example.client.setting;
public class EnumSetting extends Setting<String> {
    private final String[] values;
    public EnumSetting(String id,String name,String value,String... values){super(id,name,value);this.values=values;}
    public String[] getValues(){return values;}
    public void next(){int i=0;for(;i<values.length;i++)if(values[i].equals(get()))break;set(values[(i+1)%values.length]);}
}
