package com.example.client.setting;
public class BooleanSetting extends Setting<Boolean> { public BooleanSetting(String id,String name,boolean value){super(id,name,value);} public void toggle(){set(!get());} }
