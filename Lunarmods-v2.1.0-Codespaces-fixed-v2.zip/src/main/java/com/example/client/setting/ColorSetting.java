package com.example.client.setting;
public class ColorSetting extends Setting<Integer> { public ColorSetting(String id,String name,int value){super(id,name,value);} }
