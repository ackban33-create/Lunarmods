package com.example.client.setting;
public class KeySetting extends Setting<Integer> { public KeySetting(String id,String name,int value){super(id,name,value);} }
