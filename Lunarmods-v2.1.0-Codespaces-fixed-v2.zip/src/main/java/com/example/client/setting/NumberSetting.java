package com.example.client.setting;
public class NumberSetting extends Setting<Double> { public final double min,max,step; public NumberSetting(String id,String name,double value,double min,double max,double step){super(id,name,value);this.min=min;this.max=max;this.step=step;} }
