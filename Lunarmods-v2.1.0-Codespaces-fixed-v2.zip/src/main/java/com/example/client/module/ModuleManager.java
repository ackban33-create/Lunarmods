package com.example.client.module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import java.util.*;
public class ModuleManager {
 private final List<Module> modules=new ArrayList<Module>();
 public void register(Module m){modules.add(m);} public List<Module> getModules(){return Collections.unmodifiableList(modules);}
 public Module get(String id){for(Module m:modules)if(m.getId().equals(id))return m;return null;}
 public List<String> categories(){LinkedHashSet<String>s=new LinkedHashSet<String>();for(Module m:modules)s.add(m.getCategory());return new ArrayList<String>(s);}
 @SubscribeEvent public void tick(TickEvent.ClientTickEvent e){if(e.phase==TickEvent.Phase.END)for(Module m:modules)if(m.isEnabled())m.onTick();}
 @SubscribeEvent public void render(RenderGameOverlayEvent.Post e){if(e.type!=RenderGameOverlayEvent.ElementType.ALL)return;for(Module m:modules)if(m.isEnabled())m.onRender(e.partialTicks);}
 @SubscribeEvent public void chat(ClientChatReceivedEvent e){String msg=e.message.getUnformattedText();for(Module m:modules)if(m.isEnabled())m.onChat(msg);}
 @SubscribeEvent public void world(RenderWorldLastEvent e){for(Module m:modules)if(m.isEnabled())m.onWorldRender(e.partialTicks);}
 @SubscribeEvent public void key(InputEvent.KeyInputEvent e){int k=org.lwjgl.input.Keyboard.getEventKey();if(k!=0)for(Module m:modules)if(m.isEnabled())m.onKey(k);}
}
