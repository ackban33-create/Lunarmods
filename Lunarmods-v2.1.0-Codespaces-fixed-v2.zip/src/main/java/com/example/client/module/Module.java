package com.example.client.module;
import com.example.client.setting.Setting;
import java.util.*;
public abstract class Module {
 private final String id,name,category,description; private boolean enabled;
 private final List<Setting<?>> settings=new ArrayList<Setting<?>>();
 protected Module(String id,String name,String category){this(id,name,category,"");}
 protected Module(String id,String name,String category,String description){this.id=id;this.name=name;this.category=category;this.description=description;}
 public String getId(){return id;} public String getName(){return name;} public String getCategory(){return category;} public String getDescription(){return description;}
 public boolean isEnabled(){return enabled;}
 public void setEnabled(boolean v){if(enabled!=v){enabled=v;if(v)onEnable();else onDisable();}}
 public void toggle(){setEnabled(!enabled);} public List<Setting<?>> getSettings(){return Collections.unmodifiableList(settings);}
 protected void add(Setting<?> s){settings.add(s);} protected void onEnable(){} protected void onDisable(){} public void onTick(){} public void onRender(float partial){} public void onWorldRender(float partial){} public void onChat(String message){} public void onKey(int key){}
}
