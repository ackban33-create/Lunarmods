package com.example.client;

import com.example.client.config.ConfigManager;
import com.example.client.feature.Features;
import com.example.client.gui.ClientMenu;
import com.example.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid=ForgeClient.MODID,name=ForgeClient.NAME,version=ForgeClient.VERSION,acceptedMinecraftVersions="[1.8.9]")
public class ForgeClient {
 public static final String MODID="forgeclient189",NAME="Forge Client 1.8.9",VERSION="2.0.0";
 public static final Minecraft MC=Minecraft.getMinecraft(); public static final ModuleManager MODULES=new ModuleManager(); public static final ConfigManager CONFIG=new ConfigManager(); public static KeyBinding menuKey;
 @Mod.EventHandler public void init(FMLInitializationEvent e){
  register(new Features.FPS()); register(new Features.CPS()); register(new Features.Keystrokes()); register(new Features.Coordinates()); register(new Features.Ping()); register(new Features.ArmorStatus()); register(new Features.PotionEffects()); register(new Features.Scoreboard()); register(new Features.ItemCounter()); register(new Features.ServerAddress()); register(new Features.Clock()); register(new Features.Memory()); register(new Features.Stopwatch()); register(new Features.Cooldowns());
  register(new Features.Zoom()); register(new Features.FullBright()); register(new Features.MotionBlur()); register(new Features.HurtCam()); register(new Features.HitColor()); register(new Features.Crosshair()); register(new Features.ItemPhysics()); register(new Features.FOV());
  register(new Features.Hitbox()); register(new Features.BlockOutline()); register(new Features.TimeChanger()); register(new Features.WeatherChanger()); register(new Features.Waypoints()); register(new Features.AutoGG()); register(new Features.Quickplay()); register(new Features.UHCOverlay());
  register(new Features.Nametag()); register(new Features.ToggleSneak()); register(new Features.FreeLook()); register(new Features.Chat());
  menuKey=new KeyBinding("Open Client Menu",Keyboard.KEY_RSHIFT,"Forge Client"); ClientRegistry.registerKeyBinding(menuKey); MinecraftForge.EVENT_BUS.register(MODULES); MinecraftForge.EVENT_BUS.register(this); com.example.client.feature.FeatureHooks.register(); CONFIG.load(MODULES);
 }
 public static boolean shouldCancelHurtCam(){com.example.client.module.Module m=MODULES.get("hurtcam");return m instanceof Features.HurtCam && ((Features.HurtCam)m).shouldDisable();}
 public static void applyItemPhysics(net.minecraft.entity.item.EntityItem item,float partial){com.example.client.module.Module m=MODULES.get("itemphysics");if(!(m instanceof Features.ItemPhysics)||!m.isEnabled())return;org.lwjgl.opengl.GL11.glRotatef((item.ticksExisted+partial)*((Features.ItemPhysics)m).rotation.get().floatValue(),0,1,0);}

 private void register(com.example.client.module.Module m){MODULES.register(m);}
 @SubscribeEvent public void onKey(InputEvent.KeyInputEvent e){if(menuKey.isPressed()&&MC.currentScreen==null)MC.displayGuiScreen(new ClientMenu(MODULES,CONFIG));}
 @SubscribeEvent public void fov(FOVUpdateEvent e){com.example.client.module.Module m=MODULES.get("zoom");if(m!=null&&m.isEnabled()&&Features.zooming){Features.Zoom z=(Features.Zoom)m;e.newfov=e.newfov/z.amount.get().floatValue();return;}m=MODULES.get("fov");if(m!=null&&m.isEnabled()){Features.FOV f=(Features.FOV)m;float target=f.normal.get().floatValue();if(MC.thePlayer!=null&&MC.thePlayer.isSprinting())target=f.sprint.get().floatValue();if(!f.staticFov.get()&&MC.thePlayer!=null&&MC.thePlayer.moveForward!=0)target=f.speed.get().floatValue();e.newfov=target/90.0f;}}
}
