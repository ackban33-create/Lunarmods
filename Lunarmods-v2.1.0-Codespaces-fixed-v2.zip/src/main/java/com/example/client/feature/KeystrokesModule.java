package com.example.client.feature;
import com.example.client.module.Module;
import com.example.client.setting.BooleanSetting;
public class KeystrokesModule extends Module {
 public final BooleanSetting clicks=new BooleanSetting("keystrokesClicks","Mouse clicks",false);
 public KeystrokesModule(){super("keystrokes","Keystrokes","HUD"); add(clicks);}
}
