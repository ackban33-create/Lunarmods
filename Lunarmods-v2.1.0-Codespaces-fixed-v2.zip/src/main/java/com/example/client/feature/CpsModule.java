package com.example.client.feature;
import com.example.client.module.Module;
import com.example.client.setting.BooleanSetting;
public class CpsModule extends Module {
 public final BooleanSetting rightClick=new BooleanSetting("rightClick","Right Click",true);
 public final BooleanSetting showText=new BooleanSetting("showCPSText","Show CPS Text",false);
 public final BooleanSetting brackets=new BooleanSetting("brackets","Brackets",false);
 public final BooleanSetting background=new BooleanSetting("background","Background",false);
 public CpsModule(){super("cps","CPS","HUD"); add(rightClick);add(showText);add(brackets);add(background);}
}
