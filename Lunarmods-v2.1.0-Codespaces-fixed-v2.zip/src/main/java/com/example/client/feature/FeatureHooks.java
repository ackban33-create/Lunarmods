package com.example.client.feature;

import com.example.client.ForgeClient;
import com.example.client.module.Module;
import com.example.client.setting.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.util.HashMap;
import java.util.Map;

/** Runtime hooks for modules that need Minecraft/Forge render state. */
public final class FeatureHooks {
    private static final Minecraft MC = Minecraft.getMinecraft();
    private static final Map<Integer, Long> waypoints = new HashMap<Integer, Long>();
    private static float freeYaw, freePitch;
    private static boolean freeInit;
    private static boolean lastFreeKey;

    private FeatureHooks() {}

    public static void register() { MinecraftForge.EVENT_BUS.register(new FeatureHooks()); }

    @SubscribeEvent public void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || MC.thePlayer == null) return;
        Module free = ForgeClient.MODULES.get("freelook");
        if (free != null && free.isEnabled()) {
            if (!freeInit) { freeYaw = MC.thePlayer.rotationYaw; freePitch = MC.thePlayer.rotationPitch; freeInit = true; }
            boolean down = Keyboard.isKeyDown(Keyboard.KEY_LMENU);
            if (down) {
                int dx = Mouse.getDX(), dy = Mouse.getDY();
                freeYaw += dx * 0.15f;
                freePitch -= dy * 0.15f;
                if (freePitch > 90) freePitch = 90;
                if (freePitch < -90) freePitch = -90;
            } else if (lastFreeKey) {
                freeInit = false;
            }
            lastFreeKey = down;
        } else freeInit = false;

        Module toggle = ForgeClient.MODULES.get("togglesneak");
        if (toggle instanceof Features.ToggleSneak && toggle.isEnabled()) {
            Features.ToggleSneak t = (Features.ToggleSneak) toggle;
            if (Keyboard.isKeyDown(MC.gameSettings.keyBindSneak.getKeyCode()) && !t.sneakLatch) {
                t.toggled = !t.toggled; t.sneakLatch = true;
            }
            if (!Keyboard.isKeyDown(MC.gameSettings.keyBindSneak.getKeyCode())) t.sneakLatch = false;
            MC.thePlayer.setSneaking(t.toggled);
        }
    }

    @SubscribeEvent public void camera(EntityViewRenderEvent.CameraSetup e) {
        Module free = ForgeClient.MODULES.get("freelook");
        if (free != null && free.isEnabled() && freeInit) {
            e.setYaw(freeYaw);
            e.setPitch(freePitch);
        }
    }



    @SubscribeEvent public void livingPre(RenderLivingEvent.Pre e) {
        Module hit = ForgeClient.MODULES.get("hitcolor");
        if (hit instanceof Features.HitColor && hit.isEnabled() && e.entity instanceof EntityLivingBase) {
            int c=((Features.HitColor)hit).armor.get();
            float a=((c>>>24)&255)/255f, r=((c>>>16)&255)/255f, g=((c>>>8)&255)/255f, b=(c&255)/255f;
            if (e.entity.hurtTime>0) { GL11.glEnable(GL11.GL_BLEND); GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA); GL11.glColor4f(r,g,b,a); }
        }
    }
    @SubscribeEvent public void livingPost(RenderLivingEvent.Post e) {
        Module hit = ForgeClient.MODULES.get("hitcolor");
        if (hit instanceof Features.HitColor && hit.isEnabled() && e.entity instanceof EntityLivingBase && e.entity.hurtTime>0) GL11.glColor4f(1,1,1,1);
    }

    @SubscribeEvent public void playerSpecials(RenderPlayerEvent.Specials.Post e) {
        Module n = ForgeClient.MODULES.get("nametag");
        if (!(n instanceof Features.Nametag) || !n.isEnabled() || e.entity == MC.thePlayer) return;
        Features.Nametag tag = (Features.Nametag)n;
        double x = e.entity.lastTickPosX + (e.entity.posX-e.entity.lastTickPosX)*MC.timer.renderPartialTicks - MC.getRenderManager().viewerPosX;
        double y = e.entity.lastTickPosY + (e.entity.posY-e.entity.lastTickPosY)*MC.timer.renderPartialTicks + e.entity.height + 0.5 - MC.getRenderManager().viewerPosY;
        double z = e.entity.lastTickPosZ + (e.entity.posZ-e.entity.lastTickPosZ)*MC.timer.renderPartialTicks - MC.getRenderManager().viewerPosZ;
        drawLabel(e.entity.getCommandSenderEntity().getName(), x,y,z,tag);
    }

    private void drawLabel(String text,double x,double y,double z,Features.Nametag tag) {
        MC.entityRenderer.disableLightmap();
        GlStateManager.pushMatrix();
        GlStateManager.translate(x,y,z);
        GlStateManager.rotate(-MC.getRenderManager().playerViewY,0,1,0);
        GlStateManager.rotate(MC.getRenderManager().playerViewX,1,0,0);
        float s=0.016666668F*1.25F;
        GlStateManager.scale(-s,-s,s);
        GlStateManager.disableLighting(); GlStateManager.depthMask(false); GlStateManager.disableDepth();
        int w=MC.fontRendererObj.getStringWidth(text)/2;
        int color = tag.own.get();
        if (tag.shadow.get()) MC.fontRendererObj.drawStringWithShadow(text,-w,0,color); else MC.fontRendererObj.drawString(text,-w,0,color);
        GlStateManager.enableDepth(); GlStateManager.depthMask(true); GlStateManager.enableLighting();
        GlStateManager.popMatrix();
        MC.entityRenderer.enableLightmap();
    }

    @SubscribeEvent public void world(net.minecraftforge.client.event.RenderWorldLastEvent e) {
        Module hit = ForgeClient.MODULES.get("hitbox");
        if (hit instanceof Features.Hitbox && hit.isEnabled()) renderHitboxes((Features.Hitbox)hit,e.partialTicks);
        Module bo = ForgeClient.MODULES.get("blockoutline");
        if (bo instanceof Features.BlockOutline && bo.isEnabled()) renderBlock((Features.BlockOutline)bo);
        Module wp = ForgeClient.MODULES.get("waypoints");
        if (wp instanceof Features.Waypoints && wp.isEnabled()) renderWaypoints((Features.Waypoints)wp);
    }

    private void beginLines(){
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D(); GlStateManager.disableLighting(); GlStateManager.disableDepth();
        GlStateManager.depthMask(false); GL11.glLineWidth(2f);
    }
    private void endLines(){GlStateManager.depthMask(true);GlStateManager.enableDepth();GlStateManager.enableLighting();GlStateManager.enableTexture2D();GlStateManager.popMatrix();}

    private void renderHitboxes(Features.Hitbox f,float pt){
        beginLines();
        for(Object o:MC.theWorld.loadedEntityList){
            if (!(o instanceof Entity) || o==MC.thePlayer) continue;
            Entity e=(Entity)o; double d=MC.thePlayer.getDistanceToEntity(e); if(d>f.distance.get()) continue;
            boolean ok=(e instanceof EntityPlayer && f.players.get()) || (e instanceof IMob && f.mobs.get()) || (e instanceof EntityItem && f.items.get());
            if(!ok) continue;
            AxisAlignedBB b=e.getEntityBoundingBox().offset(-MC.getRenderManager().viewerPosX,-MC.getRenderManager().viewerPosY,-MC.getRenderManager().viewerPosZ);
            GL11.glColor4f(e instanceof EntityPlayer?0.2f:1f,e instanceof EntityPlayer?0.8f:0.3f,0.2f,1f);
            RenderGlobal.drawOutlinedBoundingBox(b,0xFFFFFFFF);
        }
        endLines();
    }

    private void renderBlock(Features.BlockOutline f){
        if(MC.objectMouseOver==null || MC.objectMouseOver.getBlockPos()==null) return;
        AxisAlignedBB b=MC.theWorld.getBlockState(MC.objectMouseOver.getBlockPos()).getBlock().getSelectedBoundingBox(MC.theWorld,MC.objectMouseOver.getBlockPos());
        if(b==null)return;
        b=b.offset(-MC.getRenderManager().viewerPosX,-MC.getRenderManager().viewerPosY,-MC.getRenderManager().viewerPosZ);
        beginLines(); GL11.glLineWidth(f.width.get().floatValue()); GL11.glColor4f(0.3f,0.7f,1f,1f); RenderGlobal.drawOutlinedBoundingBox(b,0xFFFFFFFF); endLines();
    }

    private void renderWaypoints(Features.Waypoints f){
        beginLines();
        for(Map.Entry<Integer,Long> en:waypoints.entrySet()){
            int packed=en.getKey(); int x=(packed>>20)&0xFFF; int y=(packed>>10)&0x3FF; int z=packed&0x3FF;
            if(x>2047)x-=4096;if(z>2047)z-=4096;if(y>511)y-=1024;
            double dx=x-MC.getRenderManager().viewerPosX,dy=y-MC.getRenderManager().viewerPosY,dz=z-MC.getRenderManager().viewerPosZ;
            GL11.glColor4f(1f,0.8f,0.2f,1f); GL11.glLineWidth(2f);
            AxisAlignedBB b=new AxisAlignedBB(dx,dy,dz,dx+1,dy+2,dz+1); RenderGlobal.drawOutlinedBoundingBox(b,0xFFFFFFFF);
        }
        endLines();
    }

    public static void resetFreeLook(){freeInit=false;lastFreeKey=false;}

    public static void addWaypoint(int x,int y,int z){
        int packed=((x&0xFFF)<<20)|((y&0x3FF)<<10)|(z&0x3FF); waypoints.put(packed,System.currentTimeMillis());
    }
}
