package com.example.client.feature;
import com.example.client.module.Module;
import com.example.client.setting.BooleanSetting;
import com.example.client.setting.NumberSetting;
import com.example.client.setting.KeySetting;
import org.lwjgl.input.Keyboard;
public class ZoomModule extends Module {
 public final KeySetting key=new KeySetting("zoomKeybind","Zoom Key",Keyboard.KEY_V);
 public final BooleanSetting smooth=new BooleanSetting("smoothZoom","Smooth Zoom",false);
 public final BooleanSetting variable=new BooleanSetting("variableZoom","Variable Zoom",true);
 public final NumberSetting amount=new NumberSetting("zoomAmount","Zoom Amount",4,1,20,1);
 public ZoomModule(){super("zoom","Zoom","Visuals");add(key);add(smooth);add(variable);add(amount);}
}
